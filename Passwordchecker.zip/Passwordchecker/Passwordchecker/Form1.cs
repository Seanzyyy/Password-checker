﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Text;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Passwordchecker
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int pointsSymbols = 0, pointsLetters = 0, pointsNumbers = 0;    
            int countSymbols= checkSymbols(textBox1.Text);
            int countLetters= checkLetters(textBox1.Text);    
            int countNumbers= checkNumber(textBox1.Text);   
            int pointsLength= checkLength(textBox1.Text);
            textBox2.Clear();
            if (countSymbols > 0) 
            { pointsSymbols += 15; }
            else { textBox2.Text = textBox2.Text +"Does not have symbols"; }
            if (countLetters > 0)
            { pointsLetters += 15; }
            else { textBox2.Text = textBox2.Text +", Does not have letters"; }
            if (countNumbers > 0)
            { pointsNumbers += 15; }
            else { textBox2.Text = textBox2.Text + ", Does not have Numbers"; }
            int pointsTotal = pointsSymbols + pointsLetters + pointsNumbers + pointsLength;
            if (pointsTotal>=90)
            { label3.Text = "Very strong"; }   
            else if (pointsTotal > 75) 
            { label3.Text = "Strong"; }
            else if(pointsTotal > 50)
            { label3.Text = "Medium"; }
            else if (pointsTotal > 25) 
            { label3.Text = "Weak"; }
            else
            { label3.Text = "Very weak"; }

        }

        private int checkSymbols(string text)
        {
            int count = 0;
            for (int i = 0; i < text.Length; i++)
            {
                char c = text[i];
                if (char.IsSymbol(c) || char.IsPunctuation(c))
                {
                    count++;
                }
            }
            return count;
        }
        private int checkLetters(string text) 
        {
            int count = 0;
            for (int i = 0; i < text.Length; i++)
            {
                char c = text[i];
                if (char.IsLetter(c))
                {
                    count++;
                }
            }
            return count;
        }

        private int checkNumber(string text)
        {
            int count = 0;
            for (int i = 0; i < text.Length; i++)
            {
                char c = text[i];
                if (char.IsDigit(c))
                {
                    count++;
                }
            }
            return count;
        }  

        private int checkLength(string text)
        {
            int points = 0;
            if (text.Length > 14) 
            { points += 75; }
            else if (text.Length >9)
            { points += 60; }
            else if (text.Length>6)
            { points += 40; }
            else if(text.Length>4)
            { points += 20; }
            else { points += 0; }
            return points;  
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit(); 
        }
    }
}
